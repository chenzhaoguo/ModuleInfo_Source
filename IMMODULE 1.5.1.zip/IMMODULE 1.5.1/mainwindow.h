#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMouseEvent>
#include <QThread>
#include <QTimer>

#include <QDebug>
//-----------WINDOWS----------
#ifdef Q_OS_WIN
#include <direct.h>
//-----------LINUX------------
#elif defined Q_OS_LINUX
#include <unistd.h>
#include<fcntl.h>
#endif

#include "drive/imr_driver.h"
#include "drive/driver_data.h"
#include "drive/DriverInterface.h"
#include "drive/parameters.h"

#include <iostream>
#include "opencv2/opencv.hpp"

#include "datafile.h"
#include "camerafile.h"

using namespace cv;
using namespace std;
using namespace indem;

const static int pos_min_x = 0;
const static int pos_max_x = 450;
const static int pos_min_y = 0;
const static int pos_max_y = 30;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    IDriverInterface *driver = Q_NULLPTR;
    QTimer *TimerCameraDisplay = Q_NULLPTR;
    QTimer *TimerImuData = Q_NULLPTR;
    QTimer *TimerCameraData = Q_NULLPTR;
    QTimer *TimerActive = Q_NULLPTR;

    QThread *imuTh = Q_NULLPTR;
    QThread *cameraLTh = Q_NULLPTR;
    QThread *cameraRTh = Q_NULLPTR;

    bool connectState = false;
    bool writeState = false;
    bool FuncBland = false;

    QPoint mousePosition;
    bool isMousePressed;

    IMAGE_RESOLUTION picSize;
    int camera = 0;
    int imu = 0;
    int width,height;

    dataFile *imuFile = Q_NULLPTR;
    cameraFile *camLeftFile = Q_NULLPTR;
    cameraFile *camRightFile = Q_NULLPTR;
signals:
    void toCameraData(QVector<cameraData> data);
    void toImuData(QVector<QString> data);
private:
    void ReadYamlFile(QString filePath);
private slots:
    void onCamearDisplay();
    void onImuData();
    void onCameraData();
    void onActive();
private:
    static void HMDDataCollect(IMUData* data = Q_NULLPTR);
    static void HMDDataCollectCamera(cameraData *camera_data = Q_NULLPTR);
    static void HMDInOutInfo(bool in_out = false);
protected:
    void mouseMoveEvent(QMouseEvent * event) Q_DECL_OVERRIDE;
    void mousePressEvent(QMouseEvent * event ) Q_DECL_OVERRIDE;
    void mouseReleaseEvent(QMouseEvent *) Q_DECL_OVERRIDE;
    void closeEvent(QCloseEvent*event) Q_DECL_OVERRIDE;
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    void on_open_clicked();
    void on_startrecorder_clicked();
    void on_exportcalibrtationfile_clicked();
    void on_close_clicked();
    void on_min_clicked();

    void on_pathSet_clicked();

    void on_saveCurImg_clicked();

    void on_pic1280_clicked();

    void on_pic200_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
