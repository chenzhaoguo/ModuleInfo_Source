#include "camerafile.h"

void cameraFile::setCameraSavePath(const QString pngPath, const QString excelPath)
{
    filePath = pngPath;
    cameraFile::excelPath = excelPath;
}

void cameraFile::cameraSave(const cv::Mat cameraData,const QString pngName)
{
    QDir dir;
    if (!dir.exists(filePath)) dir.mkpath(filePath);
    cv::imwrite(pngName.toStdString(),cameraData);
}

void cameraFile::cameraSet(int width, int height, QString path,int dataType)
{
    this->width = width;
    this->height = height;
    this->dataType = dataType;
    this->path = path;
}

void cameraFile::cameraListSave(const QVector<QString> picTimeMark)
{
    QDir dir;
    if (!dir.exists(excelPath)) dir.mkpath(excelPath);
    QFile pngEx(excelPath + "data.csv");
    QTextStream pngS(&pngEx);
    pngEx.open(QIODevice::Append | QIODevice::Text);
    for(auto data : picTimeMark) pngS<<data<<endl;
    pngEx.close();
}

void cameraFile::onCameraData(QVector<cameraData> data)
{
    for(int i = 0;i < data.size();++i){
        cv::Mat img(height,width,CV_8UC1,data[i]._image);

        cv::Mat left = img(cv::Range(0,height),cv::Range(0,width / 2));
        cv::Mat right = img(cv::Range(0,height),cv::Range(width / 2,width));

        long long picNum = basetime + data[i]._timeStamp * 1000000;
        QString picTimeMark = QString::number(picNum) + " " + QString::number(picNum) + ".png";

        QString picLPath = path + "/ModuleData/cam0/data/" + QString::number(picNum) + ".png";
        QString picRPath = path + "/ModuleData/cam1/data/" + QString::number(picNum) + ".png";

        if(dataType == 0)
            cameraSave(left,picLPath);
        else
            cameraSave(right,picRPath);

        cameraTimeData.push_back(picTimeMark);
        if(i == data.size() - 1){
            cameraListSave(cameraTimeData);
            cameraTimeData.clear();
        }
    }
}

cameraFile::cameraFile(){}
cameraFile::~cameraFile(){}
