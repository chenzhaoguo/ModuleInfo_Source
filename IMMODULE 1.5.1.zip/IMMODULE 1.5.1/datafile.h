#ifndef DATAFILE_H
#define DATAFILE_H

#include <QObject>
#include <QDir>
#include <QVector>
#include <QTextStream>

class dataFile : public QObject
{
    Q_OBJECT
private:
    QString filePath = "";
public:
    void setSavePath(const QString &path);
public slots:
    void onImuData(QVector<QString> data);
public:
    explicit dataFile(QObject *parent = nullptr);
};

#endif // IMUFILE_H
