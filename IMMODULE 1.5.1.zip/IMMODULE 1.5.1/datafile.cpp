#include "datafile.h"

void dataFile::setSavePath(const QString &path)
{
    filePath = path;
}

void dataFile::onImuData(QVector<QString> data)
{
    QDir dir;
    if (!dir.exists(filePath))
        dir.mkpath(filePath);
    QFile fileEx(filePath + "data.csv");
    fileEx.open(QIODevice::Append | QIODevice::Text);
    QTextStream Data(&fileEx);

    QString dataUp = "";

    for(int i = 0;i<data.size();++i){
        if(i < data.size() - 1)
            dataUp += data[i] + "\n";
        else
            dataUp += data[i];

    }
    Data<<dataUp<<endl;
    fileEx.close();
}
dataFile::dataFile(QObject *parent) : QObject(parent){}
