#include "mainwindow.h"
#include "ui_mainwindow.h"

cameraData cameraDisplay;
QVector<cameraData> cameraCache;
QVector<cameraData> cameraCacheGroup;
IMUData *curIMUDATA = Q_NULLPTR;

QVector<QString> imuDataGroup;
QVector<QString> imuData;
QVector<QString> cameraTimeData;

int curImgSize = 0;

int imuSize = 0;
int cameraSize = 0;

bool activeModule = false;
bool imuWrite = false;
bool cameraWrite = false;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_TranslucentBackground);//���ñ���͸����������괩��
    setWindowFlags(Qt::FramelessWindowHint);//ȥ�����ڱ�����
    //�����ʾ
    TimerCameraDisplay = new QTimer(this);
    connect(TimerCameraDisplay, SIGNAL(timeout()), this, SLOT(onCamearDisplay()));
    //Imu��ȡ
    TimerImuData = new QTimer(this);
    connect(TimerImuData, SIGNAL(timeout()), this, SLOT(onImuData()));
    //Camera��ȡ
    TimerCameraData = new QTimer(this);
    connect(TimerCameraData, SIGNAL(timeout()), this, SLOT(onCameraData()));
    //ģ������
    TimerActive = new QTimer(this);
    connect(TimerActive, SIGNAL(timeout()), this, SLOT(onActive()));

    SetHotplugCallback(MainWindow::HMDInOutInfo);

    ui->exportcalibrtationfile->setEnabled(false);
    ui->startrecorder->setEnabled(false);
    ui->saveCurImg->setEnabled(false);
    ui->pathLine->setFocusPolicy(Qt::NoFocus);

    ui->pathLine->setText(QCoreApplication::applicationDirPath());

    imuFile = new dataFile();
    camLeftFile = new cameraFile();
    camRightFile = new cameraFile();

    qRegisterMetaType<QVector<cameraData> >("QVector<cameraData>");
    qRegisterMetaType<QVector<QString> >("QVector<QString>");
    connect(this,SIGNAL(toImuData(QVector<QString>)),imuFile,SLOT(onImuData(QVector<QString>)),Qt::QueuedConnection);
    connect(this,SIGNAL(toCameraData(QVector<cameraData>)),camLeftFile,SLOT(onCameraData(QVector<cameraData>)),Qt::QueuedConnection);
    connect(this,SIGNAL(toCameraData(QVector<cameraData>)),camRightFile,SLOT(onCameraData(QVector<cameraData>)),Qt::QueuedConnection);

    imuFile->setSavePath(QCoreApplication::applicationDirPath() + "/ModuleData/imu0/");

    camLeftFile->setCameraSavePath(QCoreApplication::applicationDirPath() + "/ModuleData/cam0/data/",QCoreApplication::applicationDirPath() + "/ModuleData/cam0/");
    camRightFile->setCameraSavePath(QCoreApplication::applicationDirPath() + "/ModuleData/cam1/data/",QCoreApplication::applicationDirPath() + "/ModuleData/cam1/");

    imuTh = new QThread();
    cameraLTh = new QThread();
    cameraRTh = new QThread();

    imuFile->moveToThread(imuTh);
    camLeftFile->moveToThread(cameraLTh);
    camRightFile->moveToThread(cameraRTh);

    imuTh->start();
    cameraLTh->start();
    cameraRTh->start();
}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::HMDDataCollect(IMUData *data)
{
    char  imu_one[200];
    long long time_stamp = basetime + data->_timeStamp * 1000000;
    sprintf(imu_one,"%lld,%f,%f,%f,%f,%f,%f",time_stamp,
            data->_gyr[0] * (PI / 180),
            data->_gyr[1] * (PI / 180),
            data->_gyr[2] * (PI / 180),
            data->_acc[0] * _G0,
            data->_acc[1] * _G0,
            data->_acc[2] * _G0);

    curIMUDATA = data;
    if(imuWrite){
        imuData.push_back(imu_one);
        if(imuData.size() == imuSize){
            imuDataGroup.clear();
            imuDataGroup = imuData;
            imuData.clear();
        }
    }
}
void MainWindow::HMDDataCollectCamera(cameraData *camera_data)
{
    cameraDisplay._timeStamp = camera_data->_timeStamp;
    cameraDisplay._image = camera_data->_image;
    cameraDisplay._size = camera_data->_size;

    if(cameraWrite){
        cameraCache.push_back(cameraDisplay);
        if(cameraCache.size() == cameraSize){
            cameraCacheGroup.clear();
            cameraCacheGroup = cameraCache;
            cameraCache.clear();
        }
    }
}
void MainWindow::onImuData()
{
    if(imuDataGroup.size() == imuSize){
        emit toImuData(imuDataGroup);
        imuDataGroup.clear();
    }
}
void MainWindow::onCameraData()
{
    if(cameraCacheGroup.size() == cameraSize){
        emit toCameraData(cameraCacheGroup);
        cameraCacheGroup.clear();
    }
}
void MainWindow::on_saveCurImg_clicked()
{
    if(cameraDisplay._timeStamp != 0){
        cv::Mat img(height,width,CV_8UC1,cameraDisplay._image);

        cv::Mat left = img(cv::Range(0,height),cv::Range(0,width / 2));
        cv::Mat right = img(cv::Range(0,height),cv::Range(width / 2,width));

        QDir dir;
        QString filePath = ui->pathLine->text() + "/ModuleData/Image/Left/";
        if (!dir.exists(filePath))
            dir.mkpath(filePath);
        cv::imwrite(filePath.toStdString() + QString::number(cameraDisplay._timeStamp).toStdString() + ".png",left);
        filePath = ui->pathLine->text() + "/ModuleData/Image/Right/";
        if (!dir.exists(filePath))
            dir.mkpath(filePath);
        cv::imwrite(filePath.toStdString() + QString::number(cameraDisplay._timeStamp).toStdString() + ".png",right);
        ui->curImgSize->setText(QString::number(++curImgSize));
    }
}
void MainWindow::onCamearDisplay()
{
    if(cameraDisplay._timeStamp != 0){
        if(picSize){
            width = 2560;
            height = 800;
        }else{
            width = 1280;
            height = 400;
        }
        QImage *m_image = new QImage(cameraDisplay._image,width,height,QImage::Format_Indexed8);
        QImage pic = m_image->copy(0,0,width,height);
        cv::Mat left_right(height,width,CV_8UC1,pic.bits());

        namedWindow("CameraView",0);
        cvResizeWindow("CameraView", 1280, 400);
        imshow("CameraView", left_right);

        left_right.release();
        if(curIMUDATA->_timeStamp != 0){
            QString pose_info_left_acc = "accel(x,y,z): "
                    + QString::number(curIMUDATA->_acc[0],'f',6) + ","
                    + QString::number(curIMUDATA->_acc[1],'f',6) + ","
                    + QString::number(curIMUDATA->_acc[2],'f',6);
            QString pose_info_left_gyr = "gyro(x,y,z): "
                    + QString::number(curIMUDATA->_gyr[0],'f',6) + ","
                    + QString::number(curIMUDATA->_gyr[1],'f',6) + ","
                    + QString::number(curIMUDATA->_gyr[2],'f',6);
            ui->imuRet->setText("  " + pose_info_left_gyr + "\n\n" + "  " +  pose_info_left_acc);
        }
    }
}
void MainWindow::onActive()
{

}
void MainWindow::HMDInOutInfo(bool in_out)
{
    activeModule = in_out;
}

void MainWindow::on_open_clicked()
{
    if(!connectState){
        if(ui->pic25->isChecked())
            camera = 25;
        if(ui->pic50->isChecked())
            camera = 50;
        if(ui->pic100->isChecked())
            camera = 100;
        if(ui->pic200->isChecked())
            camera = 200;
        if(ui->imu100->isChecked())
            imu = 100;
        if(ui->imu200->isChecked())
            imu = 200;
        if(ui->imu500->isChecked())
            imu = 500;
        if(ui->imu1000->isChecked())
            imu = 1000;

        QString imgSize = "";
        cameraSize = camera;
        imuSize = imu;
        if(ui->pic640->isChecked()){
            picSize = RESOLUTION_640;
            imgSize = "640 * 400";
        }else{
            picSize = RESOLUTION_1280;
            imgSize = "2560 * 800";
        }
        driver = DriverFactory();
        if(driver->Open(imu, camera, picSize)){
            driver->SetIMUCallback(MainWindow::HMDDataCollect);
            driver->SetCameraCallback(MainWindow::HMDDataCollectCamera);


            TimerCameraDisplay->start(16);
            connectState = true;

            ui->exportcalibrtationfile->setEnabled(true);
            ui->startrecorder->setEnabled(true);
            ui->saveCurImg->setEnabled(true);

            ui->conState->setStyleSheet("QLabel{border:1px solid #FF4D4D4D;border-left:0;color:#39F354;font: 13px 'Microsoft YaHei UI';}");
            ui->imuRet->setStyleSheet("border:1 solid #FF333333;"
                                      "font:15px 'Microsoft YaHei UI';"
                                      "color:white");
            //ui->open->setStyleSheet("QPushButton{font:15px 'Microsoft YaHei UI';background-color: #FF4D4D4D;border:1 solid rgba(255,0,0,0.3);color:white;}"
            //                        "QPushButton::hover{border:0 white;background-color:rgba(255,255,255,0.1);border:1 solid rgba(255,0,0,0.3);color:white;font:15px 'Microsoft YaHei UI'}"
            //                        "QPushButton::pressed{border:1px solid rgba(255,255,255,0.2);background-color:rgba(255,255,255,0.2);color:white;font:15px 'Microsoft YaHei UI'}");

            ui->conState->setText(QString::fromLocal8Bit("������"));
            //ui->open->setText(QString::fromLocal8Bit("�ر�\n����"));
            ui->open->setText(QString::fromLocal8Bit("������"));
            ui->open->setEnabled(false);
            ui->nowSelect->setText(QString::fromLocal8Bit("ͼ���С: ") + imgSize + QString::fromLocal8Bit(" ͼ��Ƶ��: ") + QString::number(camera) + QString::fromLocal8Bit(" IMUƵ��: ") + QString::number(imu));
        }else{
            ui->imuRet->setStyleSheet("border:1 solid #CC3300;"
                                      "font:15px 'Microsoft YaHei UI';"
                                      "color:#CC3300");
            ui->imuRet->setText(QString::fromLocal8Bit("δ��⵽ģ�飬���顣"));
        }
    }else{
        connectState = false;
        writeState = false;

        imuWrite = false;
        cameraWrite = false;

        TimerCameraDisplay->stop();
        TimerCameraData->stop();
        TimerImuData->stop();

        if(driver != nullptr)
            destroyWindow("CameraView");

        driver->Close();

        ui->exportcalibrtationfile->setEnabled(false);
        ui->startrecorder->setEnabled(false);
        ui->saveCurImg->setEnabled(false);

        ui->conState->setStyleSheet("QLabel{border:1px solid #FF4D4D4D;border-left:0;color:red;font: 13px 'Microsoft YaHei UI';}");
        ui->conState->setText(QString::fromLocal8Bit("δ����"));

        ui->imuRet->setText(QString::fromLocal8Bit("�ȴ�ģ������"));
        ui->open->setText(QString::fromLocal8Bit("��\nģ��"));
        ui->open->setStyleSheet("QPushButton{font:15px 'Microsoft YaHei UI';background-color: #FF4D4D4D;border:1 solid rgba(255,255,255,0.3);color:white;}"
                                "QPushButton::hover{border:0 white;background-color:rgba(255,255,255,0.1);border:1 solid rgba(255,255,255,0.3);color:white;font:15px 'Microsoft YaHei UI'}"
                                "QPushButton::pressed{border:1px solid rgba(255,255,255,0.2);background-color:rgba(255,255,255,0.2);color:white;font:15px 'Microsoft YaHei UI'}");
        ui->nowSelect->setText(QString::fromLocal8Bit("ͼ���С: �� IMU֡��: �� ͼ��֡��: ��"));
        ui->startrecorder->setText(QString::fromLocal8Bit("�� ʼ\n�� ��"));
        ui->startrecorder->setStyleSheet("QPushButton{font:15px 'Microsoft YaHei UI';background-color: #FF4D4D4D;border:1 solid rgba(255,255,255,0.3);color:white;}"
                                         "QPushButton::hover{border:0 white;background-color:rgba(255,255,255,0.1);border:1 solid rgba(255,255,255,0.3);color:white;font:15px 'Microsoft YaHei UI'}"
                                         "QPushButton::pressed{border:1px solid rgba(255,255,255,0.2);background-color:rgba(255,255,255,0.2);color:white;font:15px 'Microsoft YaHei UI'}");

        curImgSize = 0;
    }
}

void MainWindow::on_startrecorder_clicked()
{
    if(!writeState){
        camLeftFile->cameraSet(width,height,ui->pathLine->text(),0);
        camRightFile->cameraSet(width,height,ui->pathLine->text(),1);
        if(ui->imuData->isChecked()){
            TimerImuData->start(1);
            imuWrite = true;
        }
        if(ui->cameraData->isChecked()){
            TimerCameraData->start(1);
            cameraWrite = true;
        }
        writeState = true;
        ui->startrecorder->setText(QString::fromLocal8Bit("�� ��\n�� ��"));
        ui->startrecorder->setStyleSheet("QPushButton{font:15px 'Microsoft YaHei UI';background-color: #FF4D4D4D;border:1 solid rgba(255,0,0,0.3);color:white;}"
                                         "QPushButton::hover{border:0 white;background-color:rgba(255,255,255,0.1);border:1 solid rgba(255,0,0,0.3);color:white;font:15px 'Microsoft YaHei UI'}"
                                         "QPushButton::pressed{border:1px solid rgba(255,255,255,0.2);background-color:rgba(255,255,255,0.2);color:white;font:15px 'Microsoft YaHei UI'}");
    }else{
        if(TimerImuData->isActive())
            TimerImuData->stop();
        if(TimerCameraData->isActive())
            TimerCameraData->stop();
        imuWrite = false;
        cameraWrite = false;
        writeState = false;
        ui->startrecorder->setText(QString::fromLocal8Bit("�� ʼ\n�� ��"));
        ui->startrecorder->setStyleSheet("QPushButton{font:15px 'Microsoft YaHei UI';background-color: #FF4D4D4D;border:1 solid rgba(255,255,255,0.3);color:white;}"
                                         "QPushButton::hover{border:0 white;background-color:rgba(255,255,255,0.1);border:1 solid rgba(255,255,255,0.3);color:white;font:15px 'Microsoft YaHei UI'}"
                                         "QPushButton::pressed{border:1px solid rgba(255,255,255,0.2);background-color:rgba(255,255,255,0.2);color:white;font:15px 'Microsoft YaHei UI'}");
    }
}

void MainWindow::on_exportcalibrtationfile_clicked()
{
    //ѡ��·��
    QString path  = QFileDialog::getExistingDirectory(this);
    if(path == "/")
        path = QCoreApplication::applicationDirPath();
    MainWindow::ReadYamlFile(path);
}
void MainWindow::ReadYamlFile(QString filePath){

    struct ModuleParamInFlash<1> ModuleData;
    size_t len = sizeof(ModuleData);
    char* bin = new char[len];
    if(driver != nullptr){
        if(imrReadHMDCalibration(driver,&bin,&len)){
            memcpy(&ModuleData,bin,len);
            //----------------------------yaml�ļ�д�뿪ʼ----------------------------------------------------------------------
            string fullpath = filePath.toStdString() + "/MODULE.yaml";
            qDebug()<<QString::fromStdString(fullpath);
            cv::FileStorage fs(fullpath, cv::FileStorage::WRITE);
            int width = ModuleData._parent._camera[0]._width;
            int height = ModuleData._parent._camera[0]._height;
            CameraParameter leftCamera = ModuleData._parent._camera[0];
            CameraParameter rightCamera = ModuleData._parent._camera[1];

            cv::Mat m_mHeadKl = cv::Mat(3, 3, CV_64FC1, leftCamera._K);
            cv::Mat m_mHeadKr = cv::Mat(3, 3, CV_64FC1, rightCamera._K);
            cv::Mat m_mHeadDl = cv::Mat(4, 1, CV_64FC1, leftCamera._D);
            cv::Mat m_mHeadDr = cv::Mat(4, 1, CV_64FC1, rightCamera._D);
            cv::Mat m_mHeadRl = cv::Mat(3, 3, CV_64FC1, leftCamera._R);
            cv::Mat m_mHeadRr = cv::Mat(3, 3, CV_64FC1, rightCamera._R);
            cv::Mat m_mHeadPl = cv::Mat(3, 4, CV_64FC1, leftCamera._P);
            cv::Mat m_mHeadPr = cv::Mat(3, 4, CV_64FC1, rightCamera._P);
            cv::Mat leftTSC(4, 4, CV_64FC1, leftCamera._TSC);
            cv::Mat rightTSC(4, 4, CV_64FC1, rightCamera._TSC);
            //���������
            fs << "cameras" << "[";
            fs << "{:" << "T_SC" << "[:"
               << leftCamera._TSC[0] << leftCamera._TSC[1] << leftCamera._TSC[2] << leftCamera._TSC[3]
               << leftCamera._TSC[4] << leftCamera._TSC[5] << leftCamera._TSC[6] << leftCamera._TSC[7]
               << leftCamera._TSC[8] << leftCamera._TSC[9] << leftCamera._TSC[10] << leftCamera._TSC[11]
               << leftCamera._TSC[12] << leftCamera._TSC[13] << leftCamera._TSC[14] << leftCamera._TSC[15]
               << "]";
            fs << "image_dimension" << "[:" << width << height << "]";
            fs << "distortion_coefficients" << "[:" << leftCamera._D[0] << leftCamera._D[1] << leftCamera._D[2] << leftCamera._D[3] << "]";
            fs << "distortion_type" << "equidistant";
            fs << "focal_length" << "[:" << leftCamera._focal_length[0] << leftCamera._focal_length[1] << "]";
            fs << "principal_point" << "[:" << leftCamera._principal_point[0] << leftCamera._principal_point[1] << "]";
            fs << "}";
            //���������
            fs << "{:" << "T_SC" << "[:"
               << rightCamera._TSC[0] << rightCamera._TSC[1] << rightCamera._TSC[2] << rightCamera._TSC[3]
               << rightCamera._TSC[4] << rightCamera._TSC[5] << rightCamera._TSC[6] << rightCamera._TSC[7]
               << rightCamera._TSC[8] << rightCamera._TSC[9] << rightCamera._TSC[10] << rightCamera._TSC[11]
               << rightCamera._TSC[12] << rightCamera._TSC[13] << rightCamera._TSC[14] << rightCamera._TSC[15]
               << "]";
            fs << "image_dimension" << "[:" << width << height << "]";
            fs << "distortion_coefficients" << "[:" << rightCamera._D[0] << rightCamera._D[1] << rightCamera._D[2] << rightCamera._D[3] << "]";
            fs << "distortion_type" << "equidistant";
            fs << "focal_length" << "[:" << rightCamera._focal_length[0] << rightCamera._focal_length[1] << "]";
            fs << "principal_point" << "[:" << rightCamera._principal_point[0] << rightCamera._principal_point[1] << "]";
            fs << "}";
            fs << "]";

            int cameraRate = 25;
            double sigmaAbsoluteTranslation = 0.0;
            double sigmaAbsoluteOrientation = 0.0;
            double sigmaCRrelativeTranslation = 0.0;
            double sigmaCRrelativeOrientation = 0.0;
            double timestampTolerance = 0.005;
            fs << "camera_params" << "{"
               << "camera_rate" << cameraRate
               << "sigma_absolute_translation" << sigmaAbsoluteTranslation
               << "sigma_absolute_orientation" << sigmaAbsoluteOrientation
               << "sigma_c_relative_translation" << sigmaCRrelativeTranslation
               << "sigma_c_relative_orientation" << sigmaCRrelativeOrientation
               << "timestampTolerance" << timestampTolerance
               << "}";
            //3.4 ������
            fs << "Rl" << m_mHeadRl << "Rr" << m_mHeadRr << "Pl" << m_mHeadPl << "Pr" << m_mHeadPr;
            fs << "Kl" << m_mHeadKl << "Kr" << m_mHeadKr << "Dl" << m_mHeadDl << "Dr" << m_mHeadDr;
            //3.5 ���imu_parameters
            double aMax = 176.0;
            double gMax = 30.0;
            double sigmaGC = 0.12000000000000000e+00;
            double sigmaAC = 9.0000000000000002e-03;
            double sigmaBg = 1.000000000000000e-01;
            double sigmaBa = 1.000000000000000e-03;
            double sigmaGwC = 4.0000000000000002e-05;
            double sigmaAwC = 4.0000000000000003e-05;
            double tau = 3600.;
            double g = 9.8019967;
            cv::Vec3d a0(0, 0, 0);
            int imuRate = 200;

            fs << "imu_params" << "{"
               << "a_max" << aMax
               << "g_max" << gMax
               << "sigma_g_c" << sigmaGC
               << "sigma_a_c" << sigmaAC
               << "sigma_bg" << sigmaBg
               << "sigma_ba" << sigmaBa
               << "sigma_gw_c" << sigmaGwC
               << "sigma_aw_c" << sigmaAwC
               << "tau" << tau
               << "g" << g
               << "a0" << a0
               << "imu_rate" << imuRate
               << "T_BS" << "[:"
               << 1. << 0. << 0. << 0.
               << 0. << 1. << 0. << 0.
               << 0. << 0. << 1. << 0.
               << 0. << 0. << 0. << 1.
               << "]"
               << "}";

            //3.6 ���Estimator parameters
            //if(std::experimental::filesystem::exists())
            //int numKeyframes = 5;
            //int numImuFrames = 3;
            //fs << "numKeyframes" << numKeyframes << "numImuFrames" << numImuFrames;

            ////3.7 ���ceres optimization options
            //fs << "ceres_options" << "{"
            //    << "minIterations" << 3
            //    << "maxIterations" << 4
            //    << "timeLimit" << 0.035
            //    << "}";

            ////3.8 ���detection
            //fs << "detection_options" << "{"
            //    << "threshold" << 30.0
            //    << "octaves" << 0
            //    << "maxNoKeypoints" << 100
            //    << "}";

            ////3.9 ���delay, display, use direct driver...
            ////string strDisplayImages = "true";
            //string strDisplayImages = "false";
            string strUseDriver = "true";
            //fs << "imageDelay" << 0.0
            //    << "displayImages" << strDisplayImages;
            fs << "useDriver" << strUseDriver;

            //3.10 ���publishing_options
            string strPublishLandmarks = "true";
            string strPublishImuPropagatedState = "true";
            string strTrackedBodyFrame = "B";
            string strVelocitiesFrame = "Wc";
            fs << "publishing_options" << "{"
               << "publish_rate" << 200
               << "publishLandmarks" << strPublishLandmarks
               << "landmarkQualityThreshold" << 1.0e-2
               << "maximumLandmarkQuality" << 0.05
               << "maxPathLength" << 20
               << "publishImuPropagatedState" << strPublishImuPropagatedState
               << "T_Wc_W" << "[:"
               << 1. << 0. << 0. << 0.
               << 0. << 1. << 0. << 0.
               << 0. << 0. << 1. << 0.
               << 0. << 0. << 0. << 1.
               << "]"
               << "trackedBodyFrame" << strTrackedBodyFrame
               << "velocitiesFrame" << strVelocitiesFrame
               << "}";

            cv::Mat acc(3, 4, CV_64FC1, ModuleData._parent._imu._Acc);
            cv::Mat gyr(3, 4, CV_64FC1, ModuleData._parent._imu._Gyr);
            fs << "Acc" << acc;
            fs << "Gyr" << gyr;
            fs.release();
            //----------------------------yaml�ļ�д�����----------------------------------------------------------------------

        }
    }
    if(bin != nullptr) {
        delete[] bin;
    }
}


void MainWindow::on_close_clicked()
{
    this->close();
}

void MainWindow::on_min_clicked()
{
    this->showMinimized();
}
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    mousePosition = event->pos();
    if (mousePosition.x()<=pos_min_x)
        return;
    if ( mousePosition.x()>=pos_max_x)
        return;
    if (mousePosition.y()<=pos_min_y )
        return;
    if (mousePosition.y()>=pos_max_y)
        return;
    isMousePressed = true;
}
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if ( isMousePressed==true )
    {
        QPoint movePot = event->globalPos() - mousePosition;
        move(movePot);
    }
}
void MainWindow::mouseReleaseEvent(QMouseEvent *)
{
    isMousePressed=false;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    Q_UNUSED(event);
    if(imuTh->isRunning()){
        disconnect();
        imuTh->quit();
        imuTh->wait();
    }
    if(cameraLTh->isRunning()){
        disconnect();
        cameraRTh->quit();
        cameraRTh->wait();
    }
    if(cameraRTh->isRunning()){
        disconnect();
        cameraRTh->quit();
        cameraRTh->wait();
    }
}

void MainWindow::on_pathSet_clicked()
{
    //ѡ��·��
    QString path  = QFileDialog::getExistingDirectory(this);
    if(path == "")
        path = QCoreApplication::applicationDirPath();

    imuFile->setSavePath(path + "/ModuleData/imu0/");
    camLeftFile->setCameraSavePath(path + "/ModuleData/cam0/data/",path + "/ModuleData/cam0/");
    camRightFile->setCameraSavePath(path + "/ModuleData/cam1/data/",path + "/ModuleData/cam1/");
    ui->pathLine->setText(path);
}
/*
        for(int i = 0;i < cameraCacheGroup.size();++i){
            unsigned char* temp = new unsigned char[cameraCacheGroup[i]._size];
            memcpy(temp,cameraCacheGroup[i]._image,cameraCacheGroup[i]._size);

            cv::Mat img(height,width,CV_8UC1,temp);

            cv::Mat left = img(cv::Range(0,height),cv::Range(0,width / 2));
            cv::Mat right = img(cv::Range(0,height),cv::Range(width / 2,width));

            long long picNum = basetime + cameraCacheGroup[i]._timeStamp * 1000000;
            QString picTimeMark = QString::number(picNum) + " " + QString::number(picNum) + ".png";

            QString picLPath = ui->pathLine->text() + "/ModuleData/cam0/data/" + QString::number(picNum) + ".png";
            QString picRPath = ui->pathLine->text() + "/ModuleData/cam1/data/" + QString::number(picNum) + ".png";

            camLeftFile->cameraSave(left,picLPath);
            camRightFile->cameraSave(right,picRPath);

            cameraTimeData.push_back(picTimeMark);
            if(cameraTimeData.size() == 50){
                camLeftFile->cameraListSave(cameraTimeData);
                camRightFile->cameraListSave(cameraTimeData);
                cameraTimeData.clear();
            }

            delete temp;
            temp = Q_NULLPTR;
        }

*/

void MainWindow::on_pic1280_clicked()
{
    if(ui->pic200->isChecked()){
        ui->pic100->click();
    }
}

void MainWindow::on_pic200_clicked()
{
    if(ui->pic1280->isChecked()){
        ui->pic640->click();
    }
}
