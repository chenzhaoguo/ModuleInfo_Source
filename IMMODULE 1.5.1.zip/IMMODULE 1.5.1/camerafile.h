#ifndef CAMERAFILE_H
#define CAMERAFILE_H

#include <QObject>
#include <QDir>
#include <QTextStream>
#include <QVector>
#include <QDebug>

//about camera
#include "opencv2/opencv.hpp"
#include "drive/DriverInterface.h"

#define _G0 9.8019967f
#define PI 3.141593
#define basetime 1000000000000000000

using namespace indem;

class cameraFile : public QObject
{
    Q_OBJECT
private:
    QString filePath = "";
    QString excelPath = "";
    QVector<QString> cameraTimeData;
    int width,height,dataType;
    QString path;
public:
    void setCameraSavePath(const QString pngPath = "", const QString excelPath = "");
    void cameraSave(const cv::Mat cameraData, const QString pngName = "");
    void cameraSet(int width, int height, QString path, int dataType);
    void cameraListSave(const QVector<QString> picTimeMark);
public slots:
    void onCameraData(QVector<cameraData> data);
public:
    cameraFile();
    ~cameraFile();
};

#endif // CAMERAFILE_H
